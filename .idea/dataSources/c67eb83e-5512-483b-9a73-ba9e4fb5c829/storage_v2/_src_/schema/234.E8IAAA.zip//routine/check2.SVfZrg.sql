create procedure check2()
  BEGIN
 UPDATE `fa_category` SET pid=0 WHERE `id` >90;	
END;

